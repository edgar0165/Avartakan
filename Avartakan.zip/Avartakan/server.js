var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var fs = require('fs');

app.use(express.static("."));
app.get('', function (req, res) {
    res.redirect('index.html')
});
server.listen(3000, function () {
    console.log("Server worked")
});

var Grass = require("./Grass.js");
var GrassEater = require("./GrassEater.js");
var GrasseaterEater = require("./GrasseaterEater.js");
var Mard = require("./Mard.js");
var Hulk = require("./Hulk.js");
//
let random = require('./random.js');
require('events').EventEmitter.defaultMaxListeners = 25;

grassArr = [];
xotakerArr = [];
gishatichArr = [];
mardArr = [];
hulkArr = [];
//
matrix = [];
//
grassHashiv = 0;
grassEaterHashiv = 0;
grassEaterEaterHashiv = 0;
hulkHashiv = 0;
mardHashiv = 0;

//
Weather = "Winter";
Weatherinit = 10;


function matrixGenerator(matrixSize, grass, grassEater, GrasseaterEater, Mard, Hulk) {
    for (let i = 0; i < matrixSize; i++) {
        matrix[i] = [];
        for (let o = 0; o < matrixSize; o++) {
            matrix[i][o] = 0;
        }
    }
    for (let i = 0; i < grass; i++) {
        let customX = Math.floor(random(matrixSize)); // 0-9
        let customY = Math.floor(random(matrixSize)); // 4
        matrix[customY][customX] = 1;
    }
    for (let i = 0; i < grassEater; i++) {
        let customX = Math.floor(random(matrixSize));
        let customY = Math.floor(random(matrixSize));
        matrix[customY][customX] = 2;
    }
    for (let i = 0; i < GrasseaterEater; i++) {
        let customX = Math.floor(random(matrixSize));
        let customY = Math.floor(random(matrixSize));
        matrix[customY][customX] = 3;
    }
    for (let i = 0; i < Mard; i++) {
        let customX = Math.floor(random(matrixSize));
        let customY = Math.floor(random(matrixSize));
        matrix[customY][customX] = 4;
    }
    for (let i = 0; i < Hulk; i++) {
        let customX = Math.floor(random(matrixSize));
        let customY = Math.floor(random(matrixSize));
        matrix[customY][customX] = 5;
    }
}
matrixGenerator(30, 30, 10, 7, 4, 2);
//! Creating MATRIX -- END
io.sockets.on("fire", () => console.log("fghj"))
// console.log(matrix)
for (var y = 0; y < matrix.length; y++) {
    for (var x = 0; x < matrix[y].length; x++) {
        if (matrix[y][x] == 1) {
            var gr = new Grass(x, y)
            grassArr.push(gr)
            grassHashiv++;
        }
        else if (matrix[y][x] == 2) {
            var xt = new GrassEater(x, y)
            xotakerArr.push(xt)
            grassEaterHashiv++;
        }
        else if (matrix[y][x] == 3) {
            var gish = new GrasseaterEater(x, y)
            gishatichArr.push(gish)
            grassEaterEaterHashiv++;
        }
        else if (matrix[y][x] == 4) {
            var md = new Mard(x, y)
            mardArr.push(md)
            mardHashiv++;
        }
        else if (matrix[y][x] == 5) {
            var hk = new Hulk(x, y)
            hulkArr.push(hk)
            mardHashiv = 0;
            hulkHashiv++;
        }
    }
}

function getWeather() {
    Weatherinit++;

    if (Weatherinit == 50) {
        Weatherinit = 10;
    }
    else if (Weatherinit == 40) {
        Weather = "Autumn";
    }
    else if (Weatherinit == 30) {
        Weather = "Summer";
    }
    else if (Weatherinit == 20) {
        Weather = "Spring";
    }
    else if (Weatherinit == 10) {

        Weather = "Winter";
    }
    //console.log(Weatherinit);

}

function drawserver() {

    if (grassArr[0] !== undefined) {
        for (var i in grassArr) {
            grassArr[i].mult();
        }
    }
    if (xotakerArr[0] !== undefined) {
        for (var i in xotakerArr) {
            xotakerArr[i].eat()
            xotakerArr[i].move()
            xotakerArr[i].mult()
            xotakerArr[i].die()
        }
    }
    if (gishatichArr[0] !== undefined) {
        for (var i in gishatichArr) {
            gishatichArr[i].eat()
            gishatichArr[i].move()
            gishatichArr[i].mult()
            gishatichArr[i].die()
        }
    }
    if (mardArr[0] !== undefined) {
        for (var i in mardArr) {
            mardArr[i].eat1()
            mardArr[i].eat2()
            mardArr[i].move()
            mardArr[i].mult()
            mardArr[i].die()
        }
    }
    if (hulkArr[0] !== undefined) {
        for (var i in hulkArr) {
            hulkArr[i].eat1()
            hulkArr[i].eat2()
            hulkArr[i].eat3()
            hulkArr[i].move()
            hulkArr[i].mult()
            hulkArr[i].die()
        }
    }


    io.on("connection", function (socket) {
        socket.on("eartquake", function (arr) {
            var x = arr[0];
            var y = arr[1];
            var directions = [
                [x - 1, y - 1],
                [x - 2, y - 2],
                [x - 3, y - 3],
                // [x - 4, y - 4],
                // [x - 5, y - 5],
                //[x, y - 1],
                [x + 1, y - 1],
                [x + 2, y - 2],
                [x + 3, y - 3],
                // [x + 4, y - 4],
                // [x + 5, y - 5],
                //[x - 1, y],
                //[x + 1, y],
                [x - 1, y + 1],
                [x - 2, y + 2],
                [x - 3, y + 3],
                // [x - 4, y + 4],
                // [x - 5, y + 5],
                //[x, y + 1],
                [x + 1, y + 1],
                [x + 2, y + 2],
                [x + 3, y + 3],
                // [x + 4, y + 4],
                // [x + 5, y + 5],
                //
                [x + 2, y],
                [x + 4, y],
                // [x + 6, y],
                // [x + 8, y],
                //
                [x - 2, y],
                [x - 4, y],
                // [x - 6, y],
                // [x - 8, y],
                //
                [x + 1, y+1],
                [x + 3, y+1],
                // [x + 5, y+1],
                // [x + 7, y+1],
                //
                [x + 1, y-1],
                [x + 3, y-1],
                // [x + 5, y-1],
                // [x + 7, y-1],
                //                
                [x - 1, y+1],
                [x - 3, y+1],
                // [x - 5, y+1],
                // [x - 7, y+1],
                //
                [x - 1, y-1],
                [x - 3, y-1],
                // [x - 5, y-1],
                // [x - 7, y-1],
                //
                [x , y+ 2],
                [x , y+ 4],
                // [x , y+ 6],
                // [x , y+ 8],
                //
                [x , y- 2],
                [x , y- 4],
                // [x , y- 6],
                // [x , y- 8],
                //
                [x + 1, y+1],
                [x + 1, y+3],
                // [x + 1, y+5],
                // [x + 1, y+7],
                //
                [x + 1, y-1],
                [x + 1, y-3],
                // [x + 1, y-5],
                // [x + 1, y-7],
                //
                [x - 1, y+1],
                [x - 1, y+3],
                // [x - 1, y+5],
                // [x - 1, y+7],
                //
                [x - 1, y-1],
                [x - 1, y-3]
                // [x - 1, y-5],
                // [x - 1, y-7]
                  
            ];

            if (matrix[y][x] == 1) {
                for (var i in grassArr) {
                    if (y === grassArr[i].y && x === grassArr[i].x) {
                        grassArr.splice(i, 1);
                        break;
                    };
                }
            } else if (matrix[y][x] == 2) {
                for (var i in xotakerArr) {
                    if (y === xotakerArr[i].y && x === xotakerArr[i].x) {
                        xotakerArr.splice(i, 1);
                        break;
                    };
                }
            }
            else if (matrix[y][x] == 3) {
                for (var i in gishatichArr) {
                    if (y === gishatichArr[i].y && x === gishatichArr[i].x) {
                        gishatichArr.splice(i, 1);
                        break;
                    };
                }
            }
            else if (matrix[y][x] == 4) {
                for (var i in mardArr) {
                    if (y === mardArr[i].y && x === mardArr[i].x) {
                        mardArr.splice(i, 1);
                        break;
                    };
                }
            }
            else if (matrix[y][x] == 5) {
                for (var i in hulkArr) {
                    if (y === hulkArr[i].y && x === hulkArrr[i].x) {
                        hulkArr.splice(i, 1);
                        break;
                    };
                }
            }
            matrix[y][x] = 0;
            for (var i in directions) {
                let harevanx = directions[i][0];
                let harevany = directions[i][1];
                let hulkx = directions[i][0];
                let hulky = directions[i][1];

                if (matrix[hulky][hulkx] == 5) {
                    for (var i in hulkArr) {
                        if (y === hulkArr[i].y && x === hulkArr[i].x) {
                            hulkArr.splice(i, 1);
                            break;
                        };
                    }
                } 
                else if (matrix[harevany][harevanx] == 1) {
                    for (var i in grassArr) {
                        if (y === grassArr[i].y && x === grassArr[i].x) {
                            grassArr.splice(i, 1);
                            break;
                        };
                    }
                } 
                else if (matrix[harevany][harevanx] == 2) {
                    for (var i in xotakerArr) {
                        if (y === xotakerArr[i].y && x === xotakerArr[i].x) {
                            grassEater.splice(i, 1);
                            break;
                        };
                    }
                }
                else if (matrix[harevany][harevanx] == 3) {
                    for (var i in gishatichArr) {
                        if (y === gishatichArr[i].y && x === gishatichArr[i].x) {
                            gishatichArr.splice(i, 1);
                            break;
                        };
                    }
                }
                else if (matrix[harevany][harevanx] == 4) {
                    for (var i in mardArr) {
                        if (y === mardArr[i].y && x ===mardArr[i].x) {
                            mardArr.splice(i, 1);
                            break;
                        };
                    }
                }
                else {
                    break;
                }
                matrix[harevany][harevanx] = 0;
                matrix[hulky][hulkx] = 4;
            }

            io.sockets.emit("data", sendData);
        });

    });







    getWeather();
    let sendData = {
        matrix: matrix,
        grassCounter: grassHashiv,
        grassEaterCounter: grassEaterHashiv,
        grassEaterEaterCounter: grassEaterEaterHashiv,
        hulkCounter: hulkHashiv,
        mardCounter: mardHashiv,
        weatherserver: Weather,
        weathertiv: Weatherinit
    }

    io.sockets.emit("data", sendData);
}
var obj1 = { "info1": [] };
var obj2 = { "info2": [] };
var obj3 = { "info3": [] };
var obj4 = { "info4": [] };
var obj5 = { "info5": [] };

function writefile() {
    var file = "Statics.json";
    obj1.info1.push({ "cnvac xoteri qanak ": grassHashiv });
    obj2.info2.push({ "cnvac xotakerneri qanak ": grassEaterHashiv });
    obj3.info3.push({ "cnvac gishatichneri qanak ": grassEaterEaterHashiv });
    obj4.info4.push({ "cnvac hulkeri qanak ": hulkHashiv });
    obj5.info5.push({ "cnvac mardkanc qanak ": mardHashiv });
    fs.writeFileSync(file, JSON.stringify(obj1, null, 3))
    fs.writeFileSync(file, JSON.stringify(obj2, null, 3))
    fs.writeFileSync(file, JSON.stringify(obj3, null, 3))
    fs.writeFileSync(file, JSON.stringify(obj4, null, 3))
    fs.writeFileSync(file, JSON.stringify(obj5, null, 3))
}

setInterval(drawserver, 1000);
setInterval(getWeather, 5000);
setInterval(writefile, 6000);