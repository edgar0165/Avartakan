var socket = io();
var side = 8;
function setup() {
    background("#acacac");
    //! Getting DOM objects (HTML elements)
    let grassCountElement = document.getElementById('grassCount');
    let grassEaterCountElement = document.getElementById('grassEaterCount');
    let grassEaterEaterCountElement = document.getElementById('grassEaterEaterCount');
    let hulkCountElement = document.getElementById('hulkCount');
    let mardCountElement = document.getElementById('mardCount');
    ////////////////////////////////////
    var client = document.getElementById("weather")

    socket.on("data", drawMatrix);


    function drawMatrix(data) {
        
         //! after getting data pass it to matrix variable
         matrix = data.matrix;
        grassCountElement.innerText = data.grassCounter;
        grassEaterCountElement.innerText = data.grassEaterCounter;
        grassEaterEaterCountElement.innerText = data.grassEaterEaterCounter;
        hulkCountElement.innerText = data.hulkCounter;
        mardCountElement.innerText = data.mardCounter;
        //////////////////////////////////////////////////
         client.innerText = data.weatherserver;
         weathertiv = data.Weatherinit
         //console.log(data.weathertiv);
         //! Every time it creates new Canvas woth new matrix size
         createCanvas(matrix[0].length * side, matrix.length * side)
         //! clearing background by setting it to new grey color
         background('#acacac');
         //! Draw grassCount and grassEaterCount to HTML (use DOM objects to update information, yes, and use .innerText <- function)


        for (var y = 0; y < matrix.length; y++) {
            for (var x = 0; x < matrix[y].length; x++) {
                if (matrix[y][x] == 0) {
                    fill("#acacac")
                }
                else if (matrix[y][x] == 1) {
                    if(data.weathertiv >= 20 && data.weathertiv <= 40){
                         fill("#3ADF10");
                        console.log("amar kam garun")
                     }
                    else if(data.weathertiv > 40 && data.weathertiv <= 50){
                        fill("#DC6F26");
                        console.log("Ashun")
                    }
                    else if (data.weathertiv < 20){
                        fill("#E8F9FD");
                        console.log("dzmer")
                    }
                }
                else if (matrix[y][x] == 2) {
                    if(data.weathertiv >= 20 && data.weathertiv <= 40){
                        fill("#yellow");
                       console.log("amar kam garun")
                    }
                   else if(data.weathertiv > 40 && data.weathertiv < 50){
                       fill("#C9C964");
                       console.log("Ashun")
                   }
                   else if (data.weathertiv < 20){
                       fill("#BDBD00");
                       console.log("dzmer")
                   }
                    fill("yellow");
                }
                else if (matrix[y][x] == 3) {
                    if(data.weathertiv >= 20 && data.weathertiv <= 40){
                        fill("red");;
                       console.log("amar kam garun")
                    }
                   else if(data.weathertiv > 40 && data.weathertiv < 50){
                       fill("#FF6666");
                       console.log("Ashun")
                   }
                   else if (data.weathertiv < 20){
                    fill("#DC4924");
                       console.log("dzmer")
                   }
                }
                else if (matrix[y][x] == 4) {
                    fill("#CC6600");
                }
                else if (matrix[y][x] == 5) {
                    fill("#275D19");
                }
    
                rect(x * side, y * side, side, side)
                // fill("blue")
                // text(x + "" + y, x * side + side / 2, y * side + side / 2)
                //console.log(data.weathertiv);
            }
        }
    }


}

function mousePressed() {
    var x = Math.floor(mouseX / side);
    var y = Math.floor(mouseY / side);
    var arr = [x,y];
    console.log(arr);
    socket.emit("eartquake", arr)
}

// mousePressed();